/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopclasses;

/**
 *
 * @author macstudent
 */
public class Bank {

int bankId = 101;
String bankName = "TD";
   void getBankName()
   {
       System.out.println("Bank name is :" + this.bankName);
       
       
   }
   void setBankName(String name)
       {
           this.bankName = name;
       }
   
   void setBankId(int no)
       {
           this.bankId = no;
       }
   
}
