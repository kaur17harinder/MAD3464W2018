/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopclasses;
import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class OopClasses {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Bank myBank = new Bank();
        System.out.println("Bank id:" + myBank.bankId);
        System.out.println("Bank Name:" + myBank.bankName);
       
         System.out.println("**********");
         
        Bank yourBank = new Bank();
        
        myBank.bankId = 102;
        myBank.bankName = "RBC";
        
        System.out.println("Bank id:" + myBank.bankId);
        System.out.println("Bank Name:" + myBank.bankName);
         System.out.println("**********");
        System.out.println("Bank id:" + yourBank.bankId);
        System.out.println("Bank Name:" + yourBank.bankName);
        yourBank.getBankName();
         System.out.println("**********");
        
        yourBank.setBankName("Scotia");
        yourBank.getBankName();
        
        
        Scanner myInput = new Scanner(System.in);
        String name;
        int no;
        
        System.out.println("ENTER THE BANK id:");
        no = myInput.nextInt();
        yourBank.setBankId(no);
        //System.out.println("Bank id:" + yourBank.bankId);
       
        
        System.out.println("ENTER THE BANK NAME:");
        name = myInput.nextLine();
        yourBank.setBankName(name);
       // System.out.println("Bank Name:" + yourBank.bankName);
        
        
        
        Arithmetic A1 = new Arithmetic();
        System.out.println("Addition of three int  numbers:" + A1.addition(2, 4, 6));
        System.out.println("Addition of two int  numbers:" + A1.addition(2, 4));
        System.out.println("Addition of two float  numbers:" + A1.addition(2.6f, 4.6f));
        System.out.println("multiplication using object of two numbers:" + A1.multiplication(2, 4));
       //static can be called without creating objects
        System.out.println("multiplication of two numbers:" + Arithmetic.multiplication(10,20) );
        
        
        Arithmetic.n1 = 20;
        Arithmetic.n2 = 40;
        System.out.println(Arithmetic.n1 + "" + Arithmetic.n3);
         
    }
    
}
