/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4_string;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author macstudent
 */
public class Day4_String {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Books book1 = new Books(1,"The sky",8);
         Books book2 = new Books(2,"Necklace",9);
    
        ArrayList<Books> library = new ArrayList<Books>();
        library.add(book1);
        library.add(book2);
         
        
         System.out.println("No. of books:" +library.size());
          
         for(Books bk:library){
             //bk.displayInfo();
         }
          library.add(1,new Books(10,"diamond",5));
        library.forEach(bk -> {
            //bk.displayInfo();
        });
        
        Collections.sort(library , new bookTitleComparator());
        for(Books bk:library){
            bk.displayInfo();
        }
    }
    
}
