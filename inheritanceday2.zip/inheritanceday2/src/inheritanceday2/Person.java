/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceday2;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Person {
    String firstName;
    String lastName;
    int age;
    
    //default constructor
    Person(){
        this.firstName = "Harry";
        this.lastName = "Potter";
        this.age = 12;
    }
    
    //parameterized constructor
    Person(String fname , String lname, int age ){
        this.firstName = fname;
        this.lastName = lname;
        this.age = age;
    }
    
    //copy constructor
    Person(Person object){
         this.firstName = object.firstName;
        this.lastName = object.lastName;
        this.age = object.age;
    }
    void read(){
      Scanner input = new Scanner(System.in);
      System.out.println("enter first name:");
      this.firstName = input.nextLine();
      
       System.out.println("enter last name:");
      this.lastName = input.nextLine();
      
       System.out.println("enter age:");
      this.age = input.nextInt();
        
    }
    
    void display(){
         System.out.println("First name:" + this.firstName);
         System.out.println("Last name:" + this.lastName);
         System.out.println("Age:" + this.age);
    }
}
