/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceday2;

/**
 *
 * @author macstudent
 */
public class Inheritanceday2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Person p1 = new Person();
       // p1.readData();
        p1.display();
        
        Person p2 = new Person("Harinder", "Kaur" ,21);
       // p1.readData();
        p2.display();
        
        Person p3 = new Person(p2);
        p3.display();
        
        
        Employee e1 = new Employee("h", "k" , 32 ,15787.9);
        e1.display();
        
         Employee e2 = new Employee();
        e1.display();
        //System.out.println("Last name :" + e2.lastName);
        e2.firstName = "J";
        e2.lastName = "D";
        e2.age = 22;
        e2.salary = 9876;
        e2.display();
       
        
        Employee e3 = new Employee("J", "D" , 22 ,95787.9);
        e3.read();
        e3.display();
    }
    
}



