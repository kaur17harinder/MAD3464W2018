/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classactivity;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */

class Person 
{
     String name;
     int age;
   Scanner sc = new Scanner(System.in);
   
    public void readData() {
       
       System.out.println("enter the name:");
       name = sc.nextLine();
       
       System.out.println("enter the age:");
       age = sc.nextInt();
       
    }

  
    public void displayData() {
       System.out.println(" name:" + (name));
       System.out.println("age:" +(age));
    }
    
}

 abstract class Employee extends Person{
  abstract void readValues();
  abstract void displayValues();
}


class Faculty extends Employee{
   String course;
   String type;
   int salary;
    Scanner sc = new Scanner(System.in);

   
   
    public void setData()
    {
       System.out.println("enter the course taken:");
        course = sc.nextLine();
    }
   
  public void getData()
    {
       System.out.println(" course taken by person :" + (course));  
    }

    @Override
    void readValues() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      System.out.println("enter the type of work pt ot ft :");
        type = sc.nextLine();
       
       System.out.println("enter the salary:");
       salary = sc.nextInt();
    }

    @Override
    void displayValues() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         System.out.println(" work done by the person:" + (type));  
       System.out.println(" salary :" + (salary));
    }
   
}