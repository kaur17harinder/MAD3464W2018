/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classactivity;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class ClassActivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Faculty f1 = new Faculty();
        f1.readData();
        f1.setData();
        f1.readValues();
        f1.displayData();
        f1.displayValues();
        f1.getData();
        
       
    }
    
}

