/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;
import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class Reservation {
    boolean[] seating = new boolean[11]; 
    Scanner input = new Scanner(System.in);

    public void start()
    {       
        while ( true )
        {
            makeReservation();
        }   
    }

    public void makeReservation()
    {
        System.out.println("Please type 1 for Smoking  or 2 for Non-Smoking: ");
        int section = input.nextInt();
        if ( section == 1 )
        {
            smokingSeat();
        }
        else
        {
            nonSmokingSeat();
        }
    }
    
     public void smokingSeat() 
    {
        for ( int a = 1; a <= 5; a++ )
        {
            if ( seating[a] == false )  
            {
                seating[a] = true;  
                System.out.printf("First Class. Seat no. %d\n", a);
                break;
            }
            else if ( seating[5] == true ) 
            {
                if ( seating[10] == true) 
                {
                    System.out.println("Sorry, flight fully booked. Next flight is in 3 hours.");
                }
                else // ask passenger if they would like an economy ticket instead
                {
                    System.out.println("Smoking Class is fully booked. Would you like Non-Smoking? 1 for Yes 2 for No");
                    int choice = input.nextInt();
                    if ( choice == 1 )
                    {
                        nonSmokingSeat();
                        start();
                    }
                    else
                    {
                        System.out.println("Next flight is in 3 hours.");
                        System.exit(0);
                    }
                }
            }
        }
    }   

    public void nonSmokingSeat() 
    {
        for ( int b = 6; b <= 10; b++ )
        {
            if ( seating[b] == false ) 
            {
                seating[b] = true; 
                System.out.printf("Economy. Seat# %d\n", b);
                break;
            }
            else if ( seating[10] == true ) 
            {
                if ( seating[5] == true) 
                {
                    System.out.println("Sorry, flight fully booked. Next flight is in 3 hours.");
                   System.exit(0);
                }
                else
                {
                    System.out.println("Economy is fully booked. Would you like First Class? 1 for Yes 2 for No");
                    int choice = input.nextInt();
                    if ( choice == 1 )
                    {
                        smokingSeat();
                        start();
                    }
                    else
                    {
                        System.out.println("Next flight is in 3 hours");
                          System.exit(0);
}
                }
            }
        }
    }
}
