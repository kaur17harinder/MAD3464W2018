/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
/**
 *
 * @author 730546
 */
public class JDBCOperations {
   static Connection conn;
   static PreparedStatement stmt;
   static ResultSet rs;
   static String USER = "root";
   static String PASS = "";
   
   public static void main(String[] args)
   {
     
        connectDB();
        selectDB();
        
        insertDB();
        selectDB();
        
        updateDB();
        selectDB();
        
        deleteDB();
        selectDB();
        
        closeDB();

   }
   static void connectDB(){
       try{
           Class.forName("com.mysql.jdbc.Driver");
           conn = DriverManager.getConnection("jdbc:mysql://localhost/madwinter18", USER, PASS);
           
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
   }
   static void selectDB(){
       try{
           stmt = conn.prepareStatement("select * from Person");
           rs = stmt.executeQuery();
           while(rs.next()){
            System.out.println("ID : " + rs.getInt(1) +
                    " FirstName : " + rs.getString("firstname") +
                    " LastName :" + rs.getString("lastname") +
                    " Age :" + rs.getInt("age"));
           }
       }
       catch(SQLException e){
          e.printStackTrace(); 
       }
   }
    static void insertDB(){
        try{
       stmt = conn.prepareStatement("insert into Person values(?,?,?,?)");
       stmt.setInt(1,102);
       stmt.setString(2,"jay");
       stmt.setString(3,"dee");
       stmt.setInt(4,21);
       
       int i =stmt.executeUpdate();
       System.out.println(i+"Record inserted");
        }
        catch(SQLException se){
           se.printStackTrace();
        }
   }
    
    static void deleteDB(){
        try{
    stmt = conn.prepareStatement(" DELETE FROM Person WHERE ID = ?  ");
    stmt.setInt(1,102);
    int nrec = stmt.executeUpdate();
    System.out.println(nrec + "updation occurs");
    
            }
        catch(SQLException se){
            se.printStackTrace(); 
        }
}
   
    static void updateDB(){
        try{
            stmt = conn.prepareStatement("UPDATE Person SET firstname = ?, lastname = ?, age = ? WHERE id = ?");
            
            stmt.setString(1, "Kulpreet");
            stmt.setString(2, "Kaur");
            stmt.setInt(3, 12);
            stmt.setInt(4, 101);
            
            
            int nrec = stmt.executeUpdate();
            System.out.println(nrec + " records inserted");
           
        }
        catch(SQLException e){
            e.printStackTrace();
        }        
    }
    
    static void closeDB(){
            try{
                if (conn!= null){
                    conn.close();
                }
            }
            catch(SQLException e){
                e.printStackTrace();;
            }
        }

}
