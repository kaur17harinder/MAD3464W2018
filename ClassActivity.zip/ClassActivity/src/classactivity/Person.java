/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classactivity;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */




class Person 
{
     String name;
     int age;
   Scanner sc = new Scanner(System.in);
   
    public void readData() {
       
       System.out.println("enter the name:");
       name = sc.nextLine();
       
       System.out.println("enter the age:");
       age = sc.nextInt();
       
    }

  
    public void displayData() {
       System.out.println(" name:" + (name));
       System.out.println("age:" +(age));
    }
    
}
interface employee1{
  void readValues();
  void displayValues();
}





class Faculty extends Person implements employee1 {
   String course;
   String type;
   int salary;
    Scanner sc = new Scanner(System.in);

    @Override
    public void readValues() {
       System.out.println("enter the type of work pt ot ft :");
        type = sc.nextLine();
       
       System.out.println("enter the salary:");
       salary = sc.nextInt();
    }

    @Override
    public void displayValues() {
       System.out.println(" work done by the person:" + (type));  
       System.out.println(" salary :" + (salary));  
    }
   
    public void setData()
    {
       System.out.println("enter the course taken:");
        course = sc.nextLine();
    }
   
  public void getData()
    {
       System.out.println(" course taken by person :" + (course));  
    }
   
}