/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Arrays;
/**
 *
 * @author macstudent
 */
public class Hello {
  public static void main(String[] args){
      int number = 10;
      float percentage;
      char vowel = 'a';
      String name = "harry";
      System.out.println("value of number: " + number);  
      percentage = 98.4f;
      System.out.println("value of percentage: " + percentage);  
      System.out.println("vowel: " + vowel);  
      System.out.println("name of the user: " + name);   
      percentage = 10;
      //number = 10.23 ;
      vowel = 35;
      number = 'H';
       System.out.println("value of percentage: " + percentage);  
      System.out.println("value of number: " + number + (1+2));  
      System.out.println("vowel: " + vowel);  
      vowel = 'a';
      switch(vowel){
          case ('a' |'e' | 'i' | 'o' | 'u'):
            //case 'e': 
                //case 'i':
                    //case 'o':
                       // case 'u':
              System.out.println("Vowel");
              break;
          default:
               System.out.println("not vowel");
               break;
      }
      String province = "ontario";
      switch(province){
          case "ontario":
          System.out.println("ON"); 
          break;
          case "ALBERTA":
          System.out.println("AB"); 
          break;
          default:
          System.out.println("unavailable"); 
          break;
      }
      
      
      int numbers[] = new int[5];
      int i;
      
      for(i = 0 ;i<numbers.length;i++)
      {
          numbers[i] = (int) (Math.random()*100);
          System.out.println("numbers [" + i + "] = "+numbers[i]); 
      }
      double PI_VALUE =Math.PI;
      double power = Math.pow(2, 2);
      Math.sqrt(17);
      Math.abs(PI_VALUE);
      
      float grades[][] = new float[3][4];
      for(i=0;i<3;i++){
          for(int j =0;j<4;j++){
              grades[i][j] = 10.0f;
          }
        //  j=0 outside error onlyinthe declared scope
      }
      float randomNo;
      for(i=0;i<10;i++)
      {
          randomNo = (float)Math.random();
          System.out.println("no" +(i+1)+ "=" + randomNo );
          
      }
     int randomNum[] = new int[10];
      for(i=0;i<10;i++)
      {
          randomNum[i] = (int)(Math.random()*10);
         System.out.println("number [" + i + "] = " + randomNum[i]);
      }
      
       System.out.println("*******************");
      
      Arrays.sort(randomNum);
      for(i=0;i<10;i++)
      {
         
         System.out.println("number [" + i + "] = " + randomNum[i]);
      }
      
      for(int a=1; a <=5; a++)
      {
          for(int b=1; b <=5; b++)
          {
            if(a == 1 || a == 5  || b == 1 || b == 5)
          {
            System.out.print("*"+" ");
          }
              else 
            {
           System.out.print("  ");
            }   
         }    
       System.out.println("");    
      }  
      
       System.out.println("Second Pattern"); 
       
      for(int x =1; x<=5 ; x++)
      {
          for(int y= 1;y<=5; y++ )
          {
              System.out.print(y);  
              for(int z=4;z>1;z--)
              {
                  System.out.print(z); 
              }
          }
          System.out.println(x);  
      }
      
      
    }
}
