/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4_abstract1;

/**
 *
 * @author macstudent
 */
public class Day4_Abstract1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Shape s1 = new Shape();
        Circle c1 = new Circle();
        c1.draw();
        c1.display("here is your circle");
    }
    
}
 abstract class Shape{
        int x;
        int y;
        
       abstract void draw();
       void display(String message){
           System.out.println("message");
       }
    }
    
class Circle extends Shape{

    @Override
    void draw() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
         System.out.println("Drawing circle");
         super.x = 20;
         super.y = 30;
         System.out.println(" x = " +super.x+ " y = " +super.y);
    }
    
}
abstract class Rectangle extends Shape{
    int h;
    abstract void draw();
}